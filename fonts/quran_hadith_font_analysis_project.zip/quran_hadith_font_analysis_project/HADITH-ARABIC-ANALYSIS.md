# Hadith text and `font-arabic2.woff2` analysis

## Executive finding

The website's CSS alias `font-arabic2` points to the uploaded WOFF2 file. The file's own OpenType name table identifies it as **Adobe Arabic Regular**, version **2.006**. The font has **1,510 glyphs**, **802 Unicode cmap mappings**, and Arabic shaping/mark-positioning features.

The user-provided hadith passage is Arabic in language, but it contains a mixture of standard Arabic code points and several Perso-Arabic / Urdu-associated code points. This is a statement about **character encoding and orthographic conventions**, not a claim that the hadith text is linguistically Urdu or Persian.

The uploaded Adobe Arabic WOFF2 maps every distinct non-whitespace code point found in the exact user-supplied passage: **54/54**. It is therefore a good technical match for this specific web passage. It is not a Qur'anic Uthmani font and does not map the six Madinah Mushaf pause marks U+06D6–U+06DB.

## 1. CSS alias versus actual font identity

The page declares `font-family: 'font-arabic2'`. That is only a CSS alias. It does not identify the font family. The `src` URL points to the file stored in the `pkcid/arabic-fonts` GitHub repository. The binary metadata, rather than the alias, gives the actual identity.

| Property | Value from the uploaded WOFF2 |
|---|---|
| CSS alias on website | `font-arabic2` |
| Internal family | Adobe Arabic |
| Subfamily | Regular |
| Full name | AdobeArabic-Regular |
| PostScript name | AdobeArabic-Regular |
| Version | Version 2.006 |
| Manufacturer | Tiro Typeworks for Adobe Systems Incorporated. |
| Designer field | Tim Holloway (Arabic) and Robert Slimbach (Latin) |
| Total glyphs | 1,510 |
| Unicode cmap mappings | 802 |
| SHA-256 | `ddb24275316cbd80a1f904b9e1296b054520f3a18a42ae8d09d36d5c91dcd95c` |

The Adobe Fonts family page confirms the Adobe Arabic family and lists Robert Slimbach and Tim Holloway as designers. The embedded font metadata gives the more specific role attribution: Tim Holloway (Arabic) and Robert Slimbach (Latin). Adobe's type blog describes the font as an Adobe-commissioned OpenType typeface produced by Tiro Typeworks. See the source links in `SOURCE-REFERENCES.md`.

## 2. Type style: Naskh-oriented Arabic text typeface

Adobe Arabic is best described here as a **Naskh-based / Naskh-oriented Arabic text typeface**, rather than Nastaliq. This classification refers to the visual design of the typeface. It does not determine whether the text itself follows Uthmani rasm, Imla'i spelling or an Indo-Pak orthographic convention.

Keep these concepts separate:

- **Language:** Arabic.
- **Character repertoire / orthographic forms:** mixed standard Arabic and Perso-Arabic/Urdu-associated characters in the supplied page text.
- **Typeface:** Adobe Arabic, Naskh-oriented text design.
- **Browser presentation:** controlled by CSS direction, shaping engine, line wrapping, font loading and mark positioning. The supplied `@font-face` block alone does not prove every other layout property.

## 3. Perso-Arabic / Urdu-associated characters in the supplied text

The following distinctive code points occur in the user-pasted text (see `samples/quranohadith_original_user_text.txt`).

| Character | Code point | Unicode name | Notes |
|---|---|---|---|
| ک | U+06A9 | ARABIC LETTER KEHEH | Common in Persian/Urdu orthography; standard Arabic normally uses ك U+0643. |
| ہ | U+06C1 | ARABIC LETTER HEH GOAL | Urdu-associated form; standard Arabic text normally uses ه U+0647 for the corresponding hāʾ. |
| ی | U+06CC | ARABIC LETTER FARSI YEH | Persian/Urdu-associated yeh; Arabic uses ي U+064A or ى U+0649 depending on the word. Do not replace blindly without lexical context. |
| ۃ | U+06C3 | ARABIC LETTER TEH MARBUTA GOAL | Extended Perso-Arabic form; compare with Arabic ة U+0629 when checking the specific word. |
| ۴ ۶ ۸ ۹ | U+06F4, U+06F6, U+06F8, U+06F9 | EXTENDED ARABIC-INDIC DIGITS | Persian/Urdu-style digits in the final source/grading note. |
| ۔ | U+06D4 | ARABIC FULL STOP | Punctuation mark used in Urdu/Persian-oriented writing conventions. |

The supplied passage also uses a decomposed sequence `ا` + U+0654 (combining hamza above) in places where precomposed `أ` U+0623 may be used. Unicode NFC can compose canonically equivalent sequences, but normalisation does not by itself convert Persian/Urdu letter variants into standard Arabic letters.

### Examples visible in the supplied passage

| Supplied form | Character-level issue | Standard-Arabic comparison |
|---|---|---|
| اللَّہُ | U+06C1 Heh Goal | اللَّهُ (U+0647) |
| یَعْقُوبَ | U+06CC Farsi Yeh | يَعْقُوبَ (U+064A) |
| عَلَی | Farsi Yeh used in this word | عَلَى (U+0649, alif maqṣūrah) |
| عَدُوِّکَ | U+06A9 Keheh | عَدُوِّكَ (U+0643) |
| أَہْلِ الْكِتَابِ | U+06C1 Heh Goal | أَهْلِ الْكِتَابِ (U+0647) |
| ۴۹۶۸ | Extended Arabic-Indic/Persian digits | ٤٩٦٨ (Arabic-Indic digits) |

These are code-point comparisons, not an automatically generated corrected hadith edition. In particular, **Farsi Yeh is not always safely replaced by Arabic Yeh**: in a word such as `على`, the correct Arabic spelling uses alif maqṣūrah U+0649. Use a verified Arabic source for lexical corrections.

## 4. Does Adobe Arabic render this passage?

The font's Unicode cmap supports all 54 distinct non-whitespace code points in the user-provided text. No cmap-missing character was found for this exact specimen.

Its OpenType shaping tables contain:

- **GSUB:** `calt, ccmp, dlig, fina, frac, init, isol, jalt, liga, locl, medi, pnum, rlig, salt, ss01, ss02, ss03, swsh`
- **GPOS:** `kern, mark, mkmk`

`init`, `medi`, `fina`, `isol`, `rlig`, `liga`, `ccmp` and related substitutions help Arabic joining/ligatures; `mark` and `mkmk` are relevant to vowel-mark attachment. A cmap match is not, by itself, proof that every mark combination is positioned beautifully; the included HTML and PNG preview are visual checks.

## 5. Does this mean the passage is Urdu?

No. The passage is Arabic prose. The presence of a small group of Urdu/Persian-associated code points means the page's text encoding is not strictly standard Arabic Unicode spelling throughout. A careful description is:

> Arabic hadith prose with Urdu/Persian-influenced Perso-Arabic character forms and digits, rendered in Adobe Arabic (Naskh-oriented text typeface).

That wording separates the language from the writing-system details.

## 6. Comparison with the earlier 54-font collection

The original archive contains 54 TTF/OTF fonts. They remain the core audited collection. The uploaded `font-arabic2.woff2` is an **additional 55th reference font**, not retroactively counted in the 54-font totals.

`font_arabic2_analysis.json` records the exact per-font coverage of the user-supplied passage across the 54 original font files. That comparison is based on each font's own Unicode cmap and is distinct from the earlier Al-Fātiḥah/pause-mark test. In this exact 54-code-point specimen, **7 of the 54 original fonts map all 54 non-whitespace characters**. `Amiri-Regular.ttf` is one of those seven. `KFGQPC Uthman Taha Naskh Regular.ttf` maps 52/54, missing U+06C3 (Teh Marbuta Goal) and U+06D4 (Arabic Full Stop); those are not core Arabic letters, but they are present in the source page's exact encoding. `UthmanicHafs_V22.ttf` maps 53/54, missing the colon used by the sample's punctuation. Several Arabic fonts map between 50 and 53 characters. Bengali-only fonts map the ASCII punctuation but not the Arabic letters/marks.

This specific comparison explains why the original page can look better in Adobe Arabic than in some fonts from the Qur'anic collection: the site’s encoded text includes characters from a broader Perso-Arabic range. A text-normalized standard-Arabic edition would have a different comparison profile. Do not convert all characters by broad codepoint substitution; resolve word forms with a verified Arabic source.

Selected results from the exact 54-code-point test:

| Original font | Exact sample coverage | Missing characters |
|---|---:|---|
| Al Qalam Quran Majeed Web Regular | 54/54 | — |
| Amiri-Regular | 54/54 | — |
| Katibeh-Regular | 54/54 | — |
| MUHAMMADI QURANIC FONT | 54/54 | — |
| NotoNastaliqUrdu-Regular | 54/54 | — |
| Scheherazade Regular / Bold | 54/54 | — |
| UthmanicHafs_V22 | 53/54 | U+003A colon |
| _PDMS_Saleem_QuranFont Regular | 53/54 | U+06C3 |
| KFGQPC Uthman Taha Naskh Regular | 52/54 | U+06C3, U+06D4 |
| NotoNaskhArabic-Regular | 52/54 | U+005B, U+005D brackets |
| AmiriQuran / AmiriQuranColored | 50/54 | U+06A9, U+06C1, U+06C3, U+06D4 |

Coverage alone is not a style ranking. For example, Noto Nastaliq Urdu maps every sample character but is a Nastaliq design, while the website's uploaded Adobe Arabic is a Naskh-oriented text design. Likewise, a font missing only the source page's Urdu/Persian-specific forms may still be appropriate after a verified standard-Arabic text source is selected.

The main earlier result remains valid for a different task: KFGQPC Uthman Taha Naskh supports the ﷺ honorific and Arabic shaping features relevant to ordinary hadith prose, but does not map the six Madinah Mushaf pause signs. Those pause signs are not required for this hadith passage.

## 7. Rendering and CSS guidance

The analysis HTML in this package renders the user-provided text using the uploaded Adobe Arabic font file itself. It also shows a standard-Arabic diagnostic comparison. The original WOFF2 is kept beside the HTML so relative local paths work.

Recommended CSS shape:

```css
@font-face {
  font-family: "Adobe Arabic Audit";
  src: url("./font-arabic2.woff2") format("woff2");
  font-style: normal;
  font-weight: 400;
  font-display: swap;
}

.hadith-text {
  font-family: "Adobe Arabic Audit", serif;
  direction: rtl;
  text-align: right;
  font-synthesis: none;
  line-height: 2.1;
}
```

The fallback family remains a browser fallback for unsupported characters. For strict validation, use the cmap report plus browser DevTools' **Rendered Fonts** panel. Do not interpret a correctly-looking fallback glyph as proof that the target font contains it.

## 8. Source and verification boundaries

- The original user-pasted text is stored unnormalised in `samples/quranohadith_original_user_text.txt`.
- Islamweb's digital edition of al-Bayhaqi, *al-Sunan al-Kubra*, narration 3052, chapter *Bāb Duʿāʾ al-Qunūt*, is linked as a standard-Arabic reference. Its wording and numbering should be checked against the printed edition if scholarly textual verification is required.
- The font identity and features are read directly from the uploaded WOFF2 binary.
- Adobe's public family page independently lists the family/designers; it is not a substitute for the exact version metadata in this uploaded file.
- The GitHub repository describes itself only as CDN files for Arabic fonts; it does not itself document the license of each font. The uploaded font's internal metadata includes Adobe's license URL. Check Adobe's terms before redistribution or public hosting.

See `SOURCE-REFERENCES.md` and `FONT-LICENSE-NOTES.md`.
