# Font licensing and embedding notes

The font files in this project were supplied by the user and have been copied unchanged. OpenType `OS/2.fsType` embedding bits and name-table licence strings are not complete substitutes for the font's actual licence agreement.

Before deploying these fonts on a public website, verify:

1. The licence permits web embedding and redistribution of the font binary.
2. Any required attribution and notices are included.
3. The licence permits conversion/subsetting if you later generate WOFF/WOFF2 files.

The report's `unicode-range` is generated from the best Unicode cmap. It is technical metadata only and has no bearing on font licensing.


## Additional reference font: font-arabic2.woff2

This WOFF2 was uploaded by the user for analysis and is included in this private working package as the test input. Its OpenType metadata identifies Adobe Arabic Regular and contains the Adobe type license URL https://www.adobe.com/type/legal.html. The GitHub CDN repository from which the site references it does not itself grant a redistribution license. Do not publish, redistribute, or self-host this binary until the applicable Adobe license terms are checked.
