#!/usr/bin/env python3
"""Inspect the uploaded font-arabic2.woff2 against the stored hadith sample.

Run from any working directory:
    python inspect_hadith_font.py
Requires fontTools. Writes JSON and CSV beside this script.
"""
from pathlib import Path
import csv
import hashlib
import json
import unicodedata
from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parent
FONT_PATH = ROOT / "font-arabic2.woff2"
TEXT_PATH = ROOT / "samples" / "quranohadith_original_user_text.txt"
if not FONT_PATH.is_file():
    raise SystemExit(f"Missing {FONT_PATH.name} beside this script")
if not TEXT_PATH.is_file():
    raise SystemExit(f"Missing sample: {TEXT_PATH}")

text = TEXT_PATH.read_text(encoding="utf-8").strip()
font = TTFont(str(FONT_PATH))
name_ids = {
    1: "family", 2: "subfamily", 3: "unique_id", 4: "full_name",
    5: "version", 6: "postscript_name", 8: "manufacturer",
    9: "designer", 11: "vendor_url", 14: "license_url",
    16: "typographic_family", 17: "typographic_subfamily",
}
metadata = {}
for name_id, key in name_ids.items():
    values = []
    for record in font["name"].names:
        if record.nameID == name_id:
            try:
                value = record.toUnicode()
            except Exception:
                continue
            if value not in values:
                values.append(value)
    if values:
        metadata[key] = values

cmap = {}
for table in font["cmap"].tables:
    if table.isUnicode():
        cmap.update(table.cmap)
unique_chars = sorted(set(text), key=ord)
visible_chars = [char for char in unique_chars if not char.isspace()]
missing = [char for char in visible_chars if ord(char) not in cmap]
gsub = sorted({record.FeatureTag for record in font["GSUB"].table.FeatureList.FeatureRecord}) if "GSUB" in font else []
gpos = sorted({record.FeatureTag for record in font["GPOS"].table.FeatureList.FeatureRecord}) if "GPOS" in font else []

special = {
    0x06A9: "Persian/Urdu Keheh",
    0x06C1: "Urdu Heh Goal",
    0x06C3: "Teh Marbuta Goal",
    0x06CC: "Farsi Yeh",
    0x06D4: "Arabic Full Stop (used in Urdu/Persian-oriented text)",
}
observed = []
for char in unique_chars:
    if char.isspace():
        continue
    cp = ord(char)
    if cp in special or 0x06F0 <= cp <= 0x06F9:
        observed.append({
            "character": char,
            "codepoint": f"U+{cp:04X}",
            "unicode_name": unicodedata.name(char, "UNKNOWN"),
            "classification": special.get(cp, "Extended Arabic-Indic digit"),
            "mapped_by_font": cp in cmap,
        })

coverage = []
for font_path in sorted([*ROOT.glob("*.ttf"), *ROOT.glob("*.otf")]):
    candidate = TTFont(str(font_path), lazy=True)
    candidate_cmap = {}
    for table in candidate["cmap"].tables:
        if table.isUnicode():
            candidate_cmap.update(table.cmap)
    have = [char for char in visible_chars if ord(char) in candidate_cmap]
    miss = [char for char in visible_chars if ord(char) not in candidate_cmap]
    coverage.append({
        "filename": font_path.name,
        "glyph_count": candidate["maxp"].numGlyphs,
        "unicode_cmap_count": len(candidate_cmap),
        "hadith_test_total": len(visible_chars),
        "hadith_test_have": len(have),
        "hadith_test_missing": len(miss),
        "missing_codepoints": [f"U+{ord(char):04X}" for char in miss],
    })
    candidate.close()

result = {
    "reference_file": FONT_PATH.name,
    "sha256": hashlib.sha256(FONT_PATH.read_bytes()).hexdigest(),
    "metadata": metadata,
    "glyph_count": font["maxp"].numGlyphs,
    "unicode_cmap_count": len(cmap),
    "gsub_features": gsub,
    "gpos_features": gpos,
    "user_text_unique_codepoints_total": len(unique_chars),
    "user_text_unique_non_whitespace_codepoints": len(visible_chars),
    "user_text_missing_from_font": [
        {"character": char, "codepoint": f"U+{ord(char):04X}"} for char in missing
    ],
    "observed_perso_arabic_and_related_characters": observed,
    "original_54_font_coverage_for_exact_user_text": coverage,
    "scope_note": "The 54 original TTF/OTF files are the original audit set. font-arabic2.woff2 is an additional user-supplied reference font, not counted in the original 54.",
}
(ROOT / "font_arabic2_analysis.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
)
with (ROOT / "hadith_character_inventory.csv").open("w", encoding="utf-8-sig", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["Character", "Code point", "Unicode name", "Classification", "Adobe Arabic cmap support"])
    for char in unique_chars:
        if char.isspace():
            continue
        cp = ord(char)
        classification = special.get(
            cp,
            "Extended Arabic-Indic digit" if 0x06F0 <= cp <= 0x06F9 else "Arabic/Latin punctuation or Arabic letters/marks",
        )
        writer.writerow([
            char, f"U+{cp:04X}", unicodedata.name(char, "UNKNOWN"),
            classification, "yes" if cp in cmap else "no",
        ])

print(f"Font family: {metadata.get('family', ['unknown'])[0]}")
print(f"Glyphs: {font['maxp'].numGlyphs}; Unicode mappings: {len(cmap)}")
print(f"Hadith sample: {len(visible_chars)-len(missing)}/{len(visible_chars)} distinct non-whitespace code points mapped")
print(f"Updated: {ROOT / 'font_arabic2_analysis.json'}")
print(f"Updated: {ROOT / 'hadith_character_inventory.csv'}")
