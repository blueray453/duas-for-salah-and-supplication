# Changelog

## Expanded pause-mark audit

- Added six real pause-mark examples from Tanzil documentation.
- Added a distinct U+06DC Saktah test.
- Added a synthetic, clearly labelled glyph fixture containing all six Madinah pause marks, the paired interchangeable mark, and Saktah.
- Added U+06DD end-of-ayah, U+06DE rub-el-hizb, and U+06E9 sajdah structural glyph previews.
- Added a 54-code-point extended Qur'anic annotation gallery based on Unicode's Arabic and Arabic Extended-A charts.
- Kept all font files in the same directory as `index.html`.
- Added Python source, JSON audit data, sample UTF-8 files, and package verification script.


## Layout and shaping clarification

- Added a section distinguishing rasm/orthography, riwayah, typeface, Dabt/annotations, Mushaf page layout and browser text flow.
- Added cautious role descriptions for the supplied Arabic fonts.
- Added visible GSUB/GPOS feature details to the live previews and inventory.
- Corrected the interpretation of KFGQPC Uthman Taha Naskh: its U+FDFA and Arabic shaping support fit Sunnah.com’s stated hadith-text use case; the six Madinah pause signs are a separate Qur'anic-text requirement.
- Explicitly states that the binary audit covers only the 54 supplied fonts; external sources were used for context, not to add fonts to the audited set.


## Hadith text and external Arabic font analysis

- Added user-supplied `font-arabic2.woff2` as an additional reference font.
- Inspected its OpenType name table, glyph count, Unicode cmap and GSUB/GPOS features.
- Identified its internal family as Adobe Arabic Regular, version 2.006 (CSS alias remains `font-arabic2`).
- Added a code-point audit of the user-pasted hadith sample, including Perso-Arabic/Urdu-associated characters and extended Arabic-Indic digits.
- Added an exact-sample coverage comparison against all 54 original TTF/OTF font binaries.
- Added HTML preview, screenshot, CSV character inventory, JSON metadata and source references.
