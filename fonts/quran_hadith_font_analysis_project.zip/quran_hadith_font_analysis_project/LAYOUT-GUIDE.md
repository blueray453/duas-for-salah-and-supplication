# Qur’anic text layout: a practical distinction

“Layout” can refer to different layers. Keep these separate in software and data models.

| Layer | What it means | Example | Where it is specified |
|---|---|---|---|
| Orthography / rasm | How words are written | Uthmani vs Imla’i | Verified text edition |
| Riwayah / qira’ah | Which transmitted reading is represented | Hafs, Warsh, Qalun | Verified text edition and reading metadata |
| Script / typeface | Shape/design of letters | Naskh, Nastaliq, Kufi, Maghribi | Font and visual design |
| Dabt / annotations | Vowels, pronunciation marks, waqf and other signs | Harakat, small high letters, pause signs | Text encoding plus suitable font glyphs and mark positioning |
| Mushaf page layout | Line/page pagination and word positions | Madani 15-line; IndoPak 15-/16-line | Edition-specific page/word layout data |
| Browser text flow | Direction, joining, mark positioning, wrapping | RTL paragraph in HTML | HTML/CSS + shaping engine + GSUB/GPOS |

## How to classify a text

1. Inspect its Unicode code points and normalisation.
2. Compare the spelling of diagnostic words with a verified Uthmani/Imla’i reference.
3. Compare its vocalisation/variant forms with a verified Hafs/Warsh/etc. source.
4. Inspect the source edition metadata.
5. To reproduce a printed Mushaf, obtain that edition’s page boundaries and line/word positions. Font coverage alone cannot recover them.

## What the supplied font files tell us

- `KFGQPC Uthman Taha Naskh Regular.ttf` is a Unicode Arabic Naskh typeface. It maps U+FDFA and includes Arabic GSUB and GPOS features for contextual forms, ligatures, cursive attachment and mark placement. It does not map the six U+06D6–U+06DB Madinah pause marks.
- `KFGQPC Uthmanic Script HAFS Regular.otf` and `UthmanicHafs_V22.ttf` are separate Qur’anic/Hafs font files; both map the six Madinah pause signs, but neither supplied file maps U+FDFA.
- `AmiriQuran.ttf` and `AmiriQuranColored.ttf` map the six Madinah pause signs and U+FDFA in the supplied versions.
- `AlQuran-IndoPak-by-QuranWBW...` and `DigitalKhattIndoPak.otf` are Indo-Pak faces. Use them with matching text conventions; some fonts in this class use private-use mappings.

These classifications are technical, based on the user-supplied files’ metadata, cmap and OpenType tables. They do not verify the correctness of the Qur’anic text itself.
