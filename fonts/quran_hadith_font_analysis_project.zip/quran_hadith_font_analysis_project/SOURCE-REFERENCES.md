# Source references and attribution

This project separates the user's supplied material, local binary inspection, and external reference research.

## User-supplied page and original font URL

- Quran o Hadith, Sunan al-Kubra al-Bayhaqi 3143: https://quranohadith.com/bayhaqi/3143
- CSS font file repository: https://github.com/pkcid/arabic-fonts
- Uploaded file URL used by the page: https://cdn.jsdelivr.net/gh/pkcid/arabic-fonts/font-arabic2.woff2
- The repository README describes the repository as CDN files for Arabic fonts; it does not name the font family or identify a license: https://github.com/pkcid/arabic-fonts/blob/main/README.md

## Font identity and design

- Adobe Fonts, Adobe Arabic family: https://fonts.adobe.com/fonts/adobe-arabic
- Adobe Typekit Blog, “Adobe Arabic – sample VOLT code” (description of the Adobe-commissioned OpenType font and Tiro Typeworks production): https://blog.typekit.com/2007/06/08/adobe_arabic_sa/
- Tim Holloway designer biography at Type Network: https://typenetwork.com/font-designers/tim-holloway
- Independent research describing Adobe Arabic as Naskh-modulated: https://aaltodoc.aalto.fi/server/api/core/bitstreams/0b3cdaa6-8e0b-49e1-b23a-9c27dd468af2/content
- License URL recorded inside the uploaded font metadata: https://www.adobe.com/type/legal.html

## Arabic reference text

- Islamweb, al-Bayhaqi, *al-Sunan al-Kubra*, Book of Prayer, “Bab Du'a al-Qunut,” narration 3052, volume 2, page 211 in that digital edition: https://www.islamweb.net/ar/library/content/71/3052/باب-دعاء-القنوت
- Neighboring narration 3053 (not the target narration; useful for seeing the next entry): https://www.islamweb.net/ar/library/content/71/3053/باب-دعاء-القنوت

## Earlier Qur'anic font audit context

- Sunnah.com, About → Fonts: https://sunnah.com/about
- Tanzil, Pause Marks: https://tanzil.net/docs/pause_marks
- Quranic Arabic Corpus, Pause Marks: https://corpus.quran.com/documentation/pausemarks.jsp
- King Fahd Complex, Computer Fonts: https://qurancomplex.gov.sa/?page_id=608
- Quran Foundation, Page Layout API Guide: https://api-docs.quran.com/docs/tutorials/fonts/page-layout/

## Interpretation notes

- The uploaded WOFF2 metadata is direct binary evidence for the internal family, version, glyph count, cmap size, and OpenType feature tags.
- The Naskh-oriented classification is a design-style interpretation supported by the external typography research source; it is not a name-table field.
- The Perso-Arabic codepoint classification comes from Unicode character names and the actual code points in the user-supplied text.
- The Islamweb page is a separate digital text witness. It should not be silently substituted for the user-supplied web page text; differences in wording, diacritics, spelling, and numbering should be checked against a selected print edition where required.
