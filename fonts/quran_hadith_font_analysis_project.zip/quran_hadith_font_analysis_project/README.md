# Qur'anic font coverage project

This project audits the 54 TTF/OTF files supplied in the original font archive. It includes the fonts, source code for rebuilding the report, machine-readable audit data, and UTF-8 text fixtures.

## Open the report

1. Extract the ZIP package.
2. Keep `index.html`, all 54 original `.ttf` / `.otf` files, and the additional `font-arabic2.woff2` together in the **same directory**. There is intentionally no `fonts/` subfolder.
3. Open `index.html` in a modern browser.

The HTML uses real, selectable Arabic text; it does not use screenshots for the specimens. It includes live previews for all 18 fonts with Arabic Unicode mappings, the Al-Fātiḥah test, six genuine pause-mark examples, a Saktah example, a constructed glyph fixture, the extended annotation gallery, the full font inventory, and CSS `@font-face` / `unicode-range` declarations.

If your browser blocks local font loading from `file://`, serve the project directory locally:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000/`.

## Rebuild the report

Requires Python 3.10+.

```bash
python -m pip install -r requirements.txt
python build_report.py
```

The script discovers `.ttf` and `.otf` files in its own directory and regenerates:

- `index.html` — HTML report and visual specimens.
- `font_audit.json` — per-font Unicode coverage and metadata.

The generated report expects font files to remain beside `index.html`.

## Rebuild the hadith-specific analysis

The additional scripts use the local `font-arabic2.woff2` and the unnormalised sample in `samples/`. Run:

```bash
python inspect_hadith_font.py
python render_hadith_specimen.py
```

`inspect_hadith_font.py` regenerates `font_arabic2_analysis.json` and `hadith_character_inventory.csv`. `render_hadith_specimen.py` regenerates `specimen-images/hadith-full-adobe-arabic.png`. The image renderer requires Pillow built with RAQM support for Arabic shaping.

## Text layout and font roles

The report now separates five layers that are often all called “layout” even though they are different:

1. **Orthography / rasm** — how the words are spelled (for example, Uthmani or Imla’i). This comes from the selected text edition, not from the font file.
2. **Riwayah / qira’ah** — the reading represented by the text (for example, Hafs or Warsh). This also belongs to the verified source text and its editorial metadata. A font may support a particular reading, but it does not select it.
3. **Script / typeface** — the visual letter design (Naskh, Nastaliq, Kufi, Maghribi, etc.). Font metadata and visual specimens help identify this.
4. **Mushaf page layout** — exact page breaks, line breaks, word positions, page number and line count (for example, Madani 15-line or Indo-Pak 16-line). This requires separate page/word layout data or page-specific glyph fonts; an ordinary Unicode font does not contain it.
5. **Browser text flow** — RTL direction, Arabic joining, combining-mark placement, wrapping and fallback. This depends on HTML/CSS, browser shaping and the font’s OpenType GSUB/GPOS tables.

The per-font notes in `index.html` are engineering classifications based on the supplied filenames, font metadata, Unicode cmap and OpenType features. They are not scholarly certification of any particular Qur’anic text edition.

## Why KFGQPC Uthman Taha Naskh is not “weak” for Sunnah.com

Sunnah.com’s Fonts note recommends KFGQPC Uthman Taha Naskh, but also says that any Arabic font with a complete set of ligatures will do. It explicitly points to the Unicode honorific `ﷺ` (U+FDFA). The supplied `KFGQPC Uthman Taha Naskh Regular.ttf` maps U+FDFA and contains these OpenType features:

- GSUB: `calt`, `fina`, `init`, `liga`, `medi`
- GPOS: `curs`, `mark`, `mkmk`

The supplied file has 637 glyphs but 293 direct Unicode cmap mappings. These are different counts: many contextual forms, ligature outputs and alternates are internal glyphs reached through OpenType shaping. A lower cmap count is not a reliable font-quality ranking.

Its missing U+06D6–U+06DB marks matter when typesetting Qur’anic annotation-heavy text, but they are not the requirement stated by Sunnah.com for hadith text. For Qur’anic Hafs text with Madinah pause marks, compare `UthmanicHafs_V22.ttf` and `AmiriQuran.ttf` in the report. They map the six pause signs but do not map U+FDFA in the supplied files.

## Scope of the audit

The actual font-binary comparison is limited to the 54 TTF/OTF files in the user-supplied archive. No external font binary was added to the inventory. The test repertoire was expanded beyond Al-Fātiḥah to include six Madinah pause marks, Saktah, structural Qur’anic signs and a broader 54-code-point annotation set. External sources were used to clarify how to interpret font roles and Mushaf layout.

## What is tested

### Al-Fātiḥah

The seven-line Al-Fātiḥah sample from the earlier report is used as a baseline rendering fixture. It contains 31 distinct non-space Unicode code points. Its coverage result is a test against that exact specimen, not a claim that the font covers every Qur'anic word or mark.

### Six Madinah Mushaf pause-mark classes

The report tests the six pause classes listed in the Tanzil documentation:

| Code point | Glyph | Pause class |
|---|---|---|
| U+06D6 | ۖ | Continuation preferred |
| U+06D7 | ۗ | Pause preferred |
| U+06D8 | ۘ | Compulsory pause |
| U+06D9 | ۙ | Impermissible pause |
| U+06DA | ۚ | Permissible pause |
| U+06DB | ۛ | Interchangeable pause; appears as a pair |

The report separately tests U+06DC (ۜ), the small high seen used for Saktah in the example shown for al-Kahf 18:1. It is not counted as a seventh member of Tanzil's six listed Madinah pause classes.

There is no single short ayah that conveniently contains all six pause types. The project therefore includes the actual example excerpts listed by Tanzil for each pause class. A separate repeated-word fixture exposes all six glyphs (with the three-dot mark repeated) plus Saktah. That repeated-word fixture is explicitly labelled as a typography test, not Qur'anic wording.

### Other Qur'anic annotations

The broader 54-code-point test set combines Unicode characters identified as Qur'anic annotation signs or additions for Qur'anic orthographies across several blocks. It includes marks for pronunciation, orthographic variants, pause/stop notation, division, and other annotations. Not every item is a pause mark, and these conventions are not all used together in one Mushaf.

The extended set is:

- U+0615 and U+0617–U+061A
- U+06D6–U+06ED
- U+08CC–U+08D0
- U+08D3–U+08E2
- U+08F0–U+08F3

### Allah's Messenger (ﷺ)

The report checks U+FDFA (ﷺ) separately from Latin text. The Latin words in `Allah's Messenger (ﷺ)` should normally use the site's UI/Latin font; the Arabic font is tested for the honorific character itself.

## Main results from this font set

- 54 font files inspected.
- 18 have Arabic-block Unicode mappings; 36 are Bengali fonts with no Arabic-block coverage.
- 16 fonts map all 31 code points in the Al-Fātiḥah specimen.
- 14 fonts map all six Madinah pause-mark code points.
- 9 fonts map U+FDFA (ﷺ).
- `KFGQPC Uthman Taha Naskh Regular.ttf` maps U+FDFA, but maps none of U+06D6–U+06DB and none of the broader 54-code-point annotation set. It also misses U+0671 in the current Al-Fātiḥah fixture.
- `KFGQPC Uthmanic Script HAFS Regular.otf` maps all six pause-mark code points and all 31 Al-Fātiḥah fixture code points, but does not map U+FDFA.

These are Unicode character-map findings. A mapped character is not proof of good mark placement, correct Arabic shaping, or religious/textual correctness. A browser may also render missing characters through a fallback font. The numeric coverage table always refers to the named font's own cmap.

## Project files

- `index.html` — browser report.
- `build_report.py` — report generator.
- `font_audit.json` — machine-readable results.
- `requirements.txt` — Python dependency.
- `samples/` — Al-Fātiḥah, genuine pause examples, and synthetic stress fixtures.
- `tests/verify_project.py` — sanity check for the package and code-point fixtures.
- 54 supplied `.ttf` / `.otf` files — all in the project root next to `index.html`.

## Sources and attribution

The six pause classes and their Arabic example excerpts are reproduced from:

- Tanzil, *Pause Marks*: <https://tanzil.net/docs/pause_marks>
- The Quranic Arabic Corpus, *Pause Marks*: <https://corpus.quran.com/documentation/pausemarks.jsp>

The U+06DC Saktah excerpt `عِوَجَاۜ` (al-Kahf 18:1) can be checked in the Hafs Arabic text at:

- Quran.com, *Surah al-Kahf, verse 1*: <https://quran.com/al-kahf/1>
- HadithCritic, *al-Kahf, Sura 18, part 1*: <https://www.hadithcriticblog.com/projects/quran/sura/18/part/1/>

The extended Unicode code-point names and classification are based on:

- Unicode 18.0 Arabic names list: <https://www.unicode.org/Public/18.0.0/charts/nameslist/0600/>
- Unicode 18.0 Arabic Extended-A chart: <https://www.unicode.org/Public/18.0.0/charts/PDF/U08A0.pdf>

Tanzil's download documentation states that Qur'anic text may be copied and distributed verbatim subject to its terms, and that the source must be clearly credited and linked. The pause excerpts in this project are kept as source examples; see Tanzil's terms at <https://tanzil.net/download/>.

## Font licensing note

The font binaries are included exactly as supplied by the user. This project does not grant additional redistribution rights and does not determine whether each font may be published on a public website. Verify each font's licence with its owner/source before deploying or redistributing it.

## Additional layout and recommendation references

- Sunnah.com, About → Fonts: https://sunnah.com/about (KFGQPC Uthman Taha Naskh recommendation, ligature requirement and U+FDFA usage).
- King Fahd Complex, Computer Fonts: https://qurancomplex.gov.sa/?page_id=608 (distinguishes a Unicode Uthmani text font from the Complex’s general Naskh font and other computer-font categories).
- Quran Foundation, Page Layout API Guide: https://api-docs.quran.com/docs/tutorials/fonts/page-layout/ (separate Mushaf IDs and pagination models, including QCF, Uthmani Hafs and IndoPak 15-/16-line layouts).
- QPC font usage reference: https://github.com/nuqayah/qpc-fonts (distinguishes Unicode text faces, QPC symbols and page-specific fonts; page fonts require matching text data).


## Additional analysis: Quran o Hadith hadith text and `font-arabic2`

The project now includes the WOFF2 font file uploaded from the Quran o Hadith page and a separate, detailed analysis of that site's CSS alias and the supplied hadith string. Open `hadith-font-analysis.html` for the live specimens. Read `HADITH-ARABIC-ANALYSIS.md` for the technical findings.

Important new finding: the WOFF2 internal name table identifies `font-arabic2.woff2` as **Adobe Arabic Regular**, version 2.006. Its character map covers every distinct non-whitespace code point in the exact user-pasted passage. The passage is Arabic in language but uses several Perso-Arabic/Urdu-associated code points, including U+06A9 Keheh, U+06C1 Heh Goal, U+06CC Farsi Yeh, U+06C3 Teh Marbuta Goal and U+06F4/U+06F6/U+06F8/U+06F9 extended Arabic-Indic digits. This is a character-encoding / orthography observation, not a claim that the passage is in Urdu.

The original 54 TTF/OTF fonts remain the core audit set. The uploaded Adobe Arabic WOFF2 is an additional reference font, not included in the original 54-font statistics. `font_arabic2_analysis.json` records exact coverage of the hadith sample for all 54 original fonts plus the WOFF2 metadata.

See `SOURCE-REFERENCES.md` for external source links, and `FONT-LICENSE-NOTES.md` before redistribution or web deployment.


### Exact hadith-text comparison results

The user-provided hadith sample has 54 distinct non-whitespace code points in the stored specimen. The added Adobe Arabic WOFF2 maps all 54. Across the original 54 TTF/OTF files, 7 map all 54 code points; `KFGQPC Uthman Taha Naskh Regular.ttf` maps 52/54 (missing U+06C3 and U+06D4), and `UthmanicHafs_V22.ttf` maps 53/54 (missing the ASCII colon used by the pasted punctuation). See `font_arabic2_analysis.json` for exact per-font results.
