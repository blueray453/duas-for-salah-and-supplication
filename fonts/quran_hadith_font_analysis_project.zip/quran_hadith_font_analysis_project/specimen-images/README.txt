Specimen image collection

Qur'anic pause-mark specimen set:
- full_pause_support_page_1.png ... page_4.png: fonts whose own cmap directly maps all six Madinah pause marks.
- partial_pause_support_page_1.png: fonts with one or more missing pause-mark mappings.
- pause_glyphs_all_arabic_fonts.png: glyph-only view of six pause marks plus Saktah across the Arabic-capable fonts.
- individual/: full specimen for each Arabic-capable TTF/OTF font from the original 54-file set.

Additional hadith specimens:
- font_arabic2_specimen.png: sample of the uploaded WOFF2, identified internally as Adobe Arabic Regular.
- font_arabic2_comparison.png: the same short excerpt compared across selected fonts from the original set.
- hadith-full-adobe-arabic.png: the complete user-supplied hadith sample rendered in Adobe Arabic; only line wrapping was added for the image.

The pause-sign charts are rendered per font file without borrowing missing glyphs from system fallback fonts. The images are fixed visual comparisons; use index.html and hadith-font-analysis.html for live, selectable text.
