#!/usr/bin/env python3
"""Render the supplied hadith text using the local Adobe Arabic WOFF2.

Requires Pillow with RAQM and fontTools. Writes to specimen-images/.
"""
from pathlib import Path
import tempfile
from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont, features

ROOT = Path(__file__).resolve().parent
TEXT_PATH = ROOT / "samples" / "quranohadith_original_user_text.txt"
FONT_PATH = ROOT / "font-arabic2.woff2"
OUT_DIR = ROOT / "specimen-images"
OUT_DIR.mkdir(exist_ok=True)
if not features.check("raqm"):
    raise SystemExit("Pillow must be built with RAQM support for correct Arabic shaping")

text = TEXT_PATH.read_text(encoding="utf-8").strip()
font_tt = TTFont(str(FONT_PATH))
# Convert only in a temporary directory for Pillow. The WOFF2 in the project stays unchanged.
font_tt.flavor = None
with tempfile.TemporaryDirectory() as temp_dir:
    ttf_path = Path(temp_dir) / "AdobeArabic-Regular.ttf"
    font_tt.save(ttf_path)
    arabic_font = ImageFont.truetype(str(ttf_path), 36, layout_engine=ImageFont.Layout.RAQM)
    title_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 34)
    note_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)

    width = 2200
    margin = 100
    usable_width = width - 2 * margin
    draw_measure = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    lines, current = [], ""
    for word in text.split():
        candidate = (current + " " + word).strip()
        advance = draw_measure.textlength(candidate, font=arabic_font, direction="rtl", language="ar")
        if current and advance > usable_width:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)

    top, line_height, bottom = 180, 78, 110
    height = top + len(lines) * line_height + bottom
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    draw.text((margin, 50), "Quran o Hadith 3143 — original user-provided text", font=title_font, fill=(27, 39, 55))
    draw.text((margin, 105), "Rendered in font-arabic2.woff2 (Adobe Arabic Regular); line breaks added for this specimen only.", font=note_font, fill=(90, 101, 116))
    y = top
    for line in lines:
        draw.text((width - margin, y), line, font=arabic_font, fill=(20, 26, 35), direction="rtl", language="ar", anchor="ra")
        y += line_height
    draw.line((margin, height - bottom + 15, width - margin, height - bottom + 15), fill=(215, 220, 228), width=2)
    draw.text((margin, height - bottom + 32), "No character substitutions or Unicode normalization were applied. Font: font-arabic2.woff2.", font=note_font, fill=(90, 101, 116))
    out = OUT_DIR / "hadith-full-adobe-arabic.png"
    image.save(out, optimize=True)
    print(f"Rendered {len(lines)} lines to {out}")
