#!/usr/bin/env python3
"""Sanity-check files and fixtures in the project directory."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / "index.html"
DATA = ROOT / "font_audit.json"

fonts = sorted([*ROOT.glob("*.ttf"), *ROOT.glob("*.otf")])
assert len(fonts) == 54, f"Expected 54 font files, found {len(fonts)}"
assert HTML.exists(), "index.html missing"
assert (ROOT / "build_report.py").exists(), "build_report.py missing"
assert (ROOT / "README.md").exists(), "README.md missing"
assert (ROOT / "font-arabic2.woff2").exists(), "Reference WOFF2 missing"
assert (ROOT / "hadith-font-analysis.html").exists(), "Hadith HTML report missing"
assert (ROOT / "HADITH-ARABIC-ANALYSIS.md").exists(), "Hadith analysis markdown missing"
assert (ROOT / "inspect_hadith_font.py").exists(), "Hadith inspection script missing"
html = HTML.read_text(encoding="utf-8")
assert "url(\"fonts/" not in html and "url('fonts/" not in html, "Report unexpectedly points to a fonts/ subfolder"
assert "<img" not in html.lower(), "Report should use live text, not image specimens"
assert "U+06D6" in html and "U+06DB" in html and "U+06DC" in html
assert "Allah's Messenger" in html and "ﷺ" in html
assert "Text layout: what a font can and cannot tell you" in html
assert "Why Sunnah.com recommends KFGQPC Uthman Taha Naskh" in html
assert "Mushaf page layout" in html
report = json.loads(DATA.read_text(encoding="utf-8"))
assert report["source_font_count"] == 54
assert len(report["madani_waqf_codepoints"]) == 6
assert len(report["extended_quranic_annotation_codepoints"]) == 54
assert len(report["fonts"]) == 54
assert report["font_inventory_scope"].startswith("54 TTF/OTF files")
kfg = next(f for f in report["fonts"] if f["filename"] == "KFGQPC Uthman Taha Naskh Regular.ttf")
assert kfg["saw"] is True and kfg["waqf_have"] == 0
assert {"init", "medi", "fina", "liga", "calt"}.issubset(set(kfg["gsub"]))
assert {"curs", "mark", "mkmk"}.issubset(set(kfg["gpos"]))
assert kfg["glyphs"] == 637 and kfg["cmap_count"] == 293
for name in ["al_fatihah.txt", "madinah_pause_examples.txt", "waqf_glyph_fixture.txt", "extended_annotation_glyph_fixture.txt"]:
    assert (ROOT / "samples" / name).exists(), f"Missing sample: {name}"
waqf_fixture = (ROOT / "samples" / "waqf_glyph_fixture.txt").read_text(encoding="utf-8")
for cp in report["madani_waqf_codepoints"]:
    assert chr(cp) in waqf_fixture, f"Pause glyph U+{cp:04X} missing from fixture"
assert chr(0x06DC) in waqf_fixture, "Saktah U+06DC missing from fixture"
ext_fixture = (ROOT / "samples" / "extended_annotation_glyph_fixture.txt").read_text(encoding="utf-8")
for cp in report["extended_quranic_annotation_codepoints"]:
    assert chr(cp) in ext_fixture, f"Extended annotation U+{cp:04X} missing from fixture"
hadith_report = (ROOT / "hadith-font-analysis.html").read_text(encoding="utf-8")
hadith_data = json.loads((ROOT / "font_arabic2_analysis.json").read_text(encoding="utf-8"))
assert "Adobe Arabic" in hadith_report
assert hadith_data["metadata"]["family"][0] == "Adobe Arabic"
assert hadith_data["glyph_count"] == 1510
assert hadith_data["unicode_cmap_count"] == 802
assert not hadith_data["user_text_missing_from_font"], "Adobe Arabic misses one or more supplied hadith characters"
assert len(hadith_data["original_54_font_coverage_for_exact_user_text"]) == 54
assert any(item["codepoint"] == "U+06A9" for item in hadith_data["observed_perso_arabic_and_related_characters"])
assert any(item["codepoint"] == "U+06C1" for item in hadith_data["observed_perso_arabic_and_related_characters"])
assert any(item["codepoint"] == "U+06CC" for item in hadith_data["observed_perso_arabic_and_related_characters"])
print("Project sanity check passed: 54 original fonts, Qur'anic pause fixtures, layout guide, and additional Adobe Arabic / hadith orthography audit.")
